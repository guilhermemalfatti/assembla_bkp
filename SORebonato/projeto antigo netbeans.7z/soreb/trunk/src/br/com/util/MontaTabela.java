/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.util;

import br.com.main.Principal;
import java.util.List;

/**
 *
 * @author Alex e Guilherme
 */
public class MontaTabela {
    public void populaTabela(List<ValoresVO> listaValores){
        //Popula a tabela com os valores
        for (int i = 0; i < listaValores.size(); i++) {
            //valor, linha, coluna
            Principal.tabela.setValueAt(listaValores.get(i).getpId(), i, 0);
            Principal.tabela.setValueAt(listaValores.get(i).getEntrSist(), i, 1);
            Principal.tabela.setValueAt(listaValores.get(i).getTempCpu(), i, 2);
            Principal.tabela.setValueAt(listaValores.get(i).getPrior(), i, 3);
            Principal.tabela.setValueAt(listaValores.get(i).getFila(), i, 4);
        }
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.util;

/**
 *
 * @author Alex e Guilherme
 */
public class ValoresVO {

   
    private Integer pId;
    private Integer entrSist;
    private Integer tempCpu;
    private Integer prior;
    private String fila;
    private Boolean escalonado;

    public Integer getEntrSist() {
        return entrSist;
    }

  public Boolean getEscalonado() {
        return escalonado;
    }

    public void setEscalonado(Boolean escalonado) {
        this.escalonado = escalonado;
    }

    public void setEntrSist(Integer entrSist) {
        this.entrSist = entrSist;
    }

    public String getFila() {
        return fila;
    }

    public void setFila(String fila) {
        this.fila = fila;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public Integer getPrior() {
        return prior;
    }

    public void setPrior(Integer prior) {
        this.prior = prior;
    }

    public Integer getTempCpu() {
        return tempCpu;
    }

    public void setTempCpu(Integer tempCpu) {
        this.tempCpu = tempCpu;
    }
    
   
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Alex e Guilherme
 */
public class Leitura {
    //Método para leitura do arquivo
    public List<ValoresVO> leArquivo(String caminho){
        List<ValoresVO> listaValores = new ArrayList<ValoresVO>();
        try {
            //Passa o caminho do arquivo por parametro
            BufferedReader in = new BufferedReader(new FileReader(caminho));
            String linha;
            while((linha = in.readLine()) != null){
                ValoresVO valoresVO = new ValoresVO();
                String[] valores = linha.split("[ ]+");

                //Seta cada atributo no objeto
                valoresVO.setpId(Integer.parseInt(valores[0]));
                valoresVO.setEntrSist(Integer.parseInt(valores[1]));
                valoresVO.setTempCpu(Integer.parseInt(valores[2]));
                valoresVO.setPrior(Integer.parseInt(valores[3]));
                valoresVO.setFila(valores[4]);

                //Adiciona o objeto na lista (cada objeto é uma linha do arquivo lido)
                listaValores.add(valoresVO);
            }
            in.close();
        } 
        catch (IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return listaValores;
    }
}
